CS6300 Assignment 2 
---------------------------
Author: Praveen S V
---------------------------


# Run the tasks

```
python task1.py
python task2.py
```

Please run corresponding notebooks for Task 3 and Task 4

