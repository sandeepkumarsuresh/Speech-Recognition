#!/usr/bin/env python
# coding: utf-8

# In[13]:


import numpy as np
import matplotlib.pyplot as plt
from numpy.lib.stride_tricks import sliding_window_view
from scipy.io import wavfile


# In[14]:


def create_windows(data, hann_window, window_size, hop_size):
    # create windows over the audio signal
    data_windows = sliding_window_view(data, window_size)[::hop_size,:]
    # repeat hann windows for each window in the audio signal and multiply
    hann_windows = np.repeat(hann_window.reshape(1, -1), data_windows.shape[0], axis=0)
    # Multiply hann window with audio signal
    data_windows = np.multiply(data_windows, hann_windows)
    data_windows.shape
    return data_windows

def make_X(x, n_coeffs):
    x_pad = np.pad(x, (n_coeffs-1,))  # pad 0's in beginning
    X = sliding_window_view(x_pad, n_coeffs)  # windows of size n_coeffs
    X = X[:x.shape[0]-1, ::-1]  # keep first N-1 windows and reverse each windows
    return X


# In[15]:


def get_LPC(filepath):
    # Read WAV File
    sr, data = wavfile.read(filepath)
    data = np.array(data / 32767.0, dtype=np.float32)

    # Set parameters
    window_size = int(0.025 * sr)  # 25 ms windows
    hop_size = window_size//4

    hann_window = np.hanning(window_size)

    data_windows = create_windows(data, hann_window, window_size, hop_size)

    n_windows = data_windows.shape[0]
    n_coeffs = 20
    
    #get LPC
    A = np.zeros((n_coeffs, n_windows))
    for idx in range(n_windows):
        x = data_windows[idx][1:]
        X = make_X(data_windows[idx], n_coeffs)
        a, residuals, rank, s = np.linalg.lstsq(X, x.T)
        e = x - np.dot(X, a)
        A[:, idx] = a

    return A


# In[18]:


def extract_formants(A):
   avg_f1, avg_f2 = .0, .0
   f1s, f2s = [], []
   N = A.shape[1]
   # iterate over frames and extract formant contour
   for idx in range(N):
       roots = np.roots(A[:, idx])
       complex_roots = []
       for root in roots:
           if np.imag(root) >= 0:
               complex_roots.append(root)
       arctan = np.arctan2(np.imag(complex_roots), np.real(complex_roots))
       formants = sorted(arctan * (16000 / (2*np.pi)))
       # track averages
       avg_f1 += formants[1]
       avg_f2 += formants[2]
       f1s.append(formants[1])
       f2s.append(formants[2])
   avg_f1, avg_f2 = avg_f1/N, avg_f2/N
   return f1s, f2s, avg_f1, avg_f2


# In[20]:


# Plot formant contours
fig, axes = plt.subplots(1, 5, figsize=(25, 5))
for idx, vowel in enumerate(['aa', 'ii', 'uu', 'e', 'o']):    
    filepath = f'../recordings_16000/vowels/{vowel}_16000.wav'
    print('Vowel: ', vowel)
    A = get_LPC(filepath)
    f1s, f2s, avg_f1, avg_f2 = extract_formants(A)
    print(f'F1 (avg): {avg_f1}, F2 (avg): {avg_f2}')
    axes[idx].scatter(list(range(len(f1s))), f1s)
    axes[idx].scatter(list(range(len(f2s))),f2s)
    axes[idx].set_xlabel("t (s) →")
    axes[idx].set_ylabel("frequency (Hz) →")
    axes[idx].set_title(vowel)
    axes[idx].set_yticks(np.arange(0, 2500, 250))
plt.show()


# In[ ]:




