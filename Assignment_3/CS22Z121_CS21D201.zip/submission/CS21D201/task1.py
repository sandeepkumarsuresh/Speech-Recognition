#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
from numpy.lib.stride_tricks import sliding_window_view
from scipy.io import wavfile


# In[2]:


def create_windows(data, hann_window, window_size, hop_size):
    # create windows over the audio signal
    data_windows = sliding_window_view(data, window_size)[::hop_size,:]
    # repeat hann windows for each window in the audio signal and multiply
    hann_windows = np.repeat(hann_window.reshape(1, -1), data_windows.shape[0], axis=0)
    # Multiply hann window with audio signal
    data_windows = np.multiply(data_windows, hann_windows)
    data_windows.shape
    return data_windows

def make_X(x, n_coeffs):
    x_pad = np.pad(x, (n_coeffs-1,))  # pad 0's in beginning
    X = sliding_window_view(x_pad, n_coeffs)  # windows of size n_coeffs
    X = X[:x.shape[0]-1, ::-1]  # keep first N-1 windows and reverse each windows
    return X


# In[10]:


fig, axes = plt.subplots(1, 5, figsize=(25, 5))
for i, vowel in enumerate(['aa', 'ii', 'uu', 'e', 'o']):
    # Read the WAV file
    filepath = f'../recordings_16000/vowels/{vowel}_16000.wav'
    sr, data = wavfile.read(filepath)
    data = np.array(data / 32767.0, dtype=np.float32)
    print(data.shape, data.dtype, data.min(), data.max())

    # Set parameters
    window_size = int(0.025 * sr)  # 25 ms windows
    hop_size = window_size//2

    # make windows
    hann_window = np.hanning(window_size)
    data_windows = create_windows(data, hann_window, window_size, hop_size)
    print(data_windows.shape)

    n_windows = data_windows.shape[0]
    n_coeffs = 20

    # get LPC
    A = np.zeros((n_coeffs, n_windows))

    for idx in range(n_windows):
        x = data_windows[idx][1:]
        X = make_X(data_windows[idx], n_coeffs)
        a, residuals, rank, s = np.linalg.lstsq(X, x.T)
        e = x - np.dot(X, a)
        A[:, idx] = a
    
    # Plotting co-efficients
    axes[i].set_ylabel('co-efficients ->')
    axes[i].set_xlabel('t (frames) ->')
    axes[i].imshow(A)
    axes[i].set_title(vowel)
plt.show()


# In[ ]:




