CS6300 Assignment 2 
---------------------------
Author: Sandeep Kumar Suresh
---------------------------


The Python files are contained in the  Task folder which references to questions in the assignment.

For Some task code are not availbale since these are implemented in software such as pratt

Python Modules Used:
--------Numpy
--------Matplotlib
--------Scipy


Note:

**We have used Pratt python code to extract the Formants.

**The Files contains all the Code and nthe plots generated. 
